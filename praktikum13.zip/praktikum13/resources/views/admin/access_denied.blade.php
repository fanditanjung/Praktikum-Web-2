@extends('admin.layout.appadmin')
@section('content')
    <h1>Akses Ditolak</h1>
@endsection
