@extends('admin.layout.appadmin')
@section('content')
    <h1>Ini adalah dashboard</h1>
@endsection