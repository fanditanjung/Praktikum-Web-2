
<?php $__env->startSection('content'); ?>
    Ini adalah Dashboard
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TI15\praktikum10\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>