@extends('admin.layout.appadmin')
@section('content')
    Ini adalah Dashboard
@endsection
